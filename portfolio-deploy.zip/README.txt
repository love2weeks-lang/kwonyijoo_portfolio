배포 방법
1) 이 폴더(index.html + assets 폴더) 전체를 정적 호스팅(Netlify Drop, Cloudflare Pages, GitHub Pages, Vercel 등)에 올립니다.
2) index.html 이 첫 화면입니다. assets 폴더를 함께 올려야 이미지가 보입니다.
3) GSAP은 cdnjs 에서 불러옵니다(인터넷 연결 필요).
4) 로컬에서 확인할 때는 폴더에서 `python3 -m http.server` 실행 후 http://localhost:8000 으로 접속하세요.
